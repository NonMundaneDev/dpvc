# Historical Metadata Recovery Review Bundle

Open `index.html` through a local HTTP server. Listen at strength 1 before strength 2, then record judgments in `ratings.csv`. Read `quality_summary.md` for the WER/MOS results. All review audio is self-contained in this directory.
