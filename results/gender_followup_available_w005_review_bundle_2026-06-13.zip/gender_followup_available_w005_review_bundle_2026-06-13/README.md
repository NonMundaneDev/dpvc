# Gender Follow-Up Available W005 Listening Review

This bundle contains a compact perceptual review for the first gender-only CommonVoice follow-up checkpoint.

Question: do the `female` and `male` metadata-control outputs sound perceptibly different from the no-metadata baseline while preserving intelligibility and naturalness?

## How to open

From this bundle directory:

```bash
python3 -m http.server 8000
```

Then open:

```text
http://localhost:8000/results/listening_gender_followup_available_w005_labeled_warmup.html
```

## Listening order

For each source speaker:

1. Source
2. Baseline
3. Baseline + female control
4. Baseline + male control

## Rating sheet

Optional rating CSV:

```text
results/listening_gender_followup_available_w005_labeled_warmup_ratings.csv
```

Use short notes if file return is inconvenient. The important gate is whether the gender controls are perceptible without becoming generic timbre shifts or damaging intelligibility.

## Important limitation

This is the available-subset run: the artifact reused already-extracted CommonVoice embeddings and matched 1,181 of the 1,788 preflight-selected clips. It is not the full preflight plan yet.
