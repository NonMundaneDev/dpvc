# Control Recovery Review Bundle

Purpose: compare the earlier project-generated combined style checkpoint with the current reference guard on matched source/style rows.

Conditions:

- `legacy_combined`
- `current_reference_guard`

Listening scope:

- styles: `anger`, `happy`, `neutral`, `sad`, `whisper`
- sources: `male_1_cremad_1003`, `female_1_cremad_1002`, `cremad_1004`, `cremad_1023`, `cremad_1045`

Open `index.html` through a local HTTP server and record judgments in `ratings.csv`.
The full objective summary covers all nine styles and all eleven matched speakers.
